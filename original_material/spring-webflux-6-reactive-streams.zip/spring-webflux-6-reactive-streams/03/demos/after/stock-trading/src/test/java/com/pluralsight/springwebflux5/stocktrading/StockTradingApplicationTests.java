package com.pluralsight.springwebflux5.stocktrading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockTradingApplicationTests {

	@Test
	void contextLoads() {
	}

}
